desa = new vanillaSelectBox("#desa", {
    "keepInlineStyles":true,
    "maxHeight": 400,
    "minWidth":448,
    "search": true,
    "placeHolder": "Desa..." 
});
hru = new vanillaSelectBox("#hru", {
    "keepInlineStyles":true,
    "maxHeight": 400,
    "minWidth":448,
    "search": true,
    "placeHolder": "HRU..." 
});
pelaksana = new vanillaSelectBox("#pelaksana", {
    "keepInlineStyles":true,
    "maxHeight": 400,
    "minWidth":448,
    "search": true,
    "placeHolder": "Pelaksana..." 
});
lemdes = new vanillaSelectBox("#lemdes", {
    "keepInlineStyles":true,
    "maxHeight": 400,
    "minWidth":448,
    "search": true,
    "placeHolder": "Lembaga Desa..." 
});
// kodekabkotkec = new vanillaSelectBox("#kodekabkot-kec", {
//     "keepInlineStyles":true,
//     "maxHeight": 200,
//     "minWidth":448,
//     "search": true,
//     "placeHolder": "Pilih kode Kabupaten/Kota..." 
// });

// kodeprovkec = new vanillaSelectBox("#kodeprov-kec", {
//     "keepInlineStyles":true,
//     "maxHeight": 200,
//     "minWidth":448,
//     "search": true,
//     "placeHolder": "Pilih kode Provinsi..." 
// });


// frameworkCMS = new vanillaSelectBox("#frameworkCMS", {
//     "maxHeight": 400,
//     "search": true,
//     translations: { "all": "All", "items": "Selected" },
//     "minWidth":210,
//     "placeHolder": "Choose..." 
// });
// selectBox3 = new vanillaSelectBox("#multipleSelect", {
//     "minWidth":210,
//     "maxHeight": 200,
//     "search": true,
//     "stayOpen":true
// });