
$(document).ready(function() {
  $('#kodedesa').select2(
    {
      placeholder: "Pilih kode Desa...",
	allowClear: true
    }
  );
});

$(document).ready(function() {
  $('#desa').select2(
    {
      placeholder: "Pilih kode Desa...",
	allowClear: true
    }
  );
});
$(document).ready(function() {
  $('#pelaksana').select2(
    {
      placeholder: "Pilih kode pelaksana...",
	allowClear: true
    }
  );
});
$(document).ready(function() {
  $('#hru').select2(
    {
      placeholder: "Pilih kode HRU...",
	allowClear: true
    }
  );
});
$(document).ready(function() {
  $('#lemdes').select2(
    {
      placeholder: "Pilih kode LEMDES...",
	allowClear: true
    }
  );
});
