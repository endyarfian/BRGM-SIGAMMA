<?php

namespace App\Controllers;

use \App\Models\GambTindakanModel;
use \App\Models\GambKegiatanModel;

class UserGambutKegiatan extends BaseController
{
    protected $admgambuttindakan;
    public function __construct()
    {
        $this->GambTindakanModel = new GambTindakanModel();
        $this->GambKegiatanModel = new GambKegiatanModel();
    }
    public function index($idtindakan)
    {

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id as idtindakan, tb_tindakan_restorasi.kode_tindakan_restorasi as kodetindakan,
        tb_kegiatan.id, tb_kegiatan.kode_tindakan_restorasi, tb_kegiatan.kode_kegiatan, 
        tb_kegiatan.nama_kegiatan, tb_kegiatan.deskripsi');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->join('tb_kegiatan', 'tb_kegiatan.kode_tindakan_restorasi = tb_tindakan_restorasi.kode_tindakan_restorasi');
        $data->where('tb_tindakan_restorasi.id', $idtindakan);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id as idtindakan, tb_tindakan_restorasi.kode_tindakan_restorasi as kodetindakan');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->where('tb_tindakan_restorasi.id', $idtindakan);
        $query2 = $data->get();


        $kegiatan = $query->getResultArray();
        $tindakan2 = $query2->getResultArray();
        // dd($kegiatan);

        $tindakan = $this->GambTindakanModel->findAll();
        $data = [
            'tindakan' => $tindakan,
            'tindakan2' => $tindakan2,
            'kegiatan' => $kegiatan,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/user/gamb-kegiatan', $data);
    }
}
