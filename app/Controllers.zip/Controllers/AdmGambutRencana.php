<?php

namespace App\Controllers;

use \App\Models\GambRencanaModel;

class AdmGambutRencana extends BaseController
{
    protected $admgambutdokumen;
    public function __construct()
    {
        $this->GambRencanaModel = new GambRencanaModel();
    }
    public function index()
    {
        $doc = $this->GambRencanaModel->findAll();
        $data = [
            'doc' => $doc,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-dokumen', $data);
    }

    public function simpan_rencana()
    {
        if (!$this->validate([
            'kodedoc' => [
                'rules' => 'required|is_unique[tb_rencana.kode_rencana]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'tipedoc' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'judul' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'berlaku' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'berakhir' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'pengesah' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/rencana')->withInput()->with('validation', $validation);
        }
        $this->GambRencanaModel->save([
            'kode_rencana' => $this->request->getVar('kodedoc'),
            'tipe_rencana' => $this->request->getVar('tipedoc'),
            'judul' => $this->request->getVar('judul'),
            'tgl_berlaku' => $this->request->getVar('berlaku'),
            'tgl_berakhir' => $this->request->getVar('berakhir'),
            'pengesah' => $this->request->getVar('pengesah'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/rencana');
    }
    public function edit_rencana($id)
    {
        $this->GambRencanaModel->save([
            'id' => $id,
            'kode_rencana' => $this->request->getVar('kodedoc'),
            'tipe_rencana' => $this->request->getVar('tipedoc'),
            'judul' => $this->request->getVar('judul'),
            'tgl_berlaku' => $this->request->getVar('berlaku'),
            'tgl_berakhir' => $this->request->getVar('berakhir'),
            'pengesah' => $this->request->getVar('pengesah'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/rencana');
    }

    public function hapus_rencana($id)
    {
        $this->GambRencanaModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/rencana');
    }
}
