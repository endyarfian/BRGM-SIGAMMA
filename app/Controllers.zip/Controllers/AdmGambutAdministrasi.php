<?php

namespace App\Controllers;

use \App\Models\GambProvModel;
use \App\Models\GambKabkotModel;
use \App\Models\GambKecModel;
use \App\Models\GambDesaModel;

class AdmGambutAdministrasi extends BaseController
{
    protected $admgambutadministrasi;
    public function __construct()
    {
        $this->GambProvModel = new GambProvModel();
        $this->GambKabkotModel = new GambKabkotModel();
        $this->GambKecModel = new GambKecModel();
        $this->GambDesaModel = new GambDesaModel();
    }
    public function index()
    {
        $prov = $this->GambProvModel->findAll();
        $kabkot = $this->GambKabkotModel->findAll();
        $kec = $this->GambKecModel->findAll();
        $desa = $this->GambDesaModel->findAll();
        $data = [
            'prov' => $prov,
            'kabkot' => $kabkot,
            'kec' => $kec,
            'desa' => $desa,
            'title' => 'SIGAMMA | Data Administrasi Kawasan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-administrasi', $data);
    }

    public function simpan_prov()
    {
        if (!$this->validate([
            'kodeprov' => [
                'rules' => 'required|is_unique[tb_prov.kode_prov]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'namaprov' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('/admin/gambut/administrasi')->withInput()->with('validation', $validation);
        }
        $this->GambProvModel->save([
            'kode_prov' => $this->request->getVar('kodeprov'),
            'nama_prov' => $this->request->getVar('namaprov'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('/admin/gambut/administrasi');
    }
    public function edit_prov($id)
    {
        $this->GambProvModel->save([
            'id' => $id,
            'kode_prov' => $this->request->getVar('kodeprov'),
            'nama_prov' => $this->request->getVar('namaprov'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('/admin/gambut/administrasi');
    }

    public function hapus_prov($id)
    {
        $this->GambProvModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('/admin/gambut/administrasi');
    }
}
