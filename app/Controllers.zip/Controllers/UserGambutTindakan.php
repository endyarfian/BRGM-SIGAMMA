<?php

namespace App\Controllers;

use \App\Models\GambRencanaModel;
use \App\Models\GambTindakanModel;

class UserGambutTindakan extends BaseController
{
    protected $admgambuttindakan;
    public function __construct()
    {
        $this->GambRencanaModel = new GambRencanaModel();
        $this->GambTindakanModel = new GambTindakanModel();
    }
    public function index($idrencana)
    {

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id, tb_tindakan_restorasi.kode_tindakan_restorasi, tb_tindakan_restorasi.jenis_tindakan_restorasi, 
        tb_tindakan_restorasi.tgl_mulai, tb_tindakan_restorasi.tgl_selesai, tb_tindakan_restorasi.deskripsi, tb_tindakan_restorasi.pj');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->where('tb_rencana.id', $idrencana);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul');
        $data->where('tb_rencana.id', $idrencana);
        $query2 = $data->get();


        $tindakan = $query->getResultArray();
        $rencana2 = $query2->getResultArray();
        // dd($tindakan);

        $rencana = $this->GambRencanaModel->findAll();
        $data = [
            'rencana' => $rencana,
            'rencana2' => $rencana2,
            'tindakan' => $tindakan,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/user/gamb-tindakan', $data);
    }
}
