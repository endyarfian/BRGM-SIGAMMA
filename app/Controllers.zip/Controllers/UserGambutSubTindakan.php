<?php

namespace App\Controllers;

use \App\Models\GambTindakanModel;
use \App\Models\GambSubTindakanModel;

class UserGambutSubTindakan extends BaseController
{
    protected $admgambuttindakan;
    public function __construct()
    {
        $this->GambTindakanModel = new GambTindakanModel();
        $this->GambSubTindakanModel = new GambSubTindakanModel();
    }
    public function index($idtindakan)
    {

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id as idtindakan, tb_tindakan_restorasi.kode_tindakan_restorasi as kodetindakan,
        tb_sub_tindakan_restorasi.id, tb_sub_tindakan_restorasi.kode_sub_tindakan_restorasi, tb_sub_tindakan_restorasi.nama_sub_tindakan_restorasi, 
        tb_sub_tindakan_restorasi.volume, tb_sub_tindakan_restorasi.satuan, tb_sub_tindakan_restorasi.deskripsi, tb_sub_tindakan_restorasi.pj');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->join('tb_sub_tindakan_restorasi', 'tb_sub_tindakan_restorasi.kode_tindakan_restorasi = tb_tindakan_restorasi.kode_tindakan_restorasi');
        $data->where('tb_tindakan_restorasi.id', $idtindakan);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id as idtindakan, tb_tindakan_restorasi.kode_tindakan_restorasi as kodetindakan');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->where('tb_tindakan_restorasi.id', $idtindakan);
        $query2 = $data->get();


        $subtindakan = $query->getResultArray();
        $tindakan2 = $query2->getResultArray();
        // dd($subtindakan);

        $tindakan = $this->GambTindakanModel->findAll();
        $data = [
            'tindakan' => $tindakan,
            'tindakan2' => $tindakan2,
            'subtindakan' => $subtindakan,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/user/gamb-subtindakan', $data);
    }
}
