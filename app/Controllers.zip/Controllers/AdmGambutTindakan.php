<?php

namespace App\Controllers;

use \App\Models\GambRencanaModel;
use \App\Models\GambTindakanModel;

class AdmGambutTindakan extends BaseController
{
    protected $admgambuttindakan;
    public function __construct()
    {
        $this->GambRencanaModel = new GambRencanaModel();
        $this->GambTindakanModel = new GambTindakanModel();
    }
    public function index($idrencana)
    {

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id, tb_tindakan_restorasi.kode_tindakan_restorasi, tb_tindakan_restorasi.jenis_tindakan_restorasi, 
        tb_tindakan_restorasi.tgl_mulai, tb_tindakan_restorasi.tgl_selesai, tb_tindakan_restorasi.deskripsi, tb_tindakan_restorasi.pj');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->where('tb_rencana.id', $idrencana);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul');
        $data->where('tb_rencana.id', $idrencana);
        $query2 = $data->get();


        $tindakan = $query->getResultArray();
        $rencana2 = $query2->getResultArray();
        // dd($tindakan);

        $rencana = $this->GambRencanaModel->findAll();
        $data = [
            'rencana' => $rencana,
            'rencana2' => $rencana2,
            'tindakan' => $tindakan,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-tindakan', $data);
    }

    public function simpan_tindakan($idrencana)
    {
        if (!$this->validate([
            'kodetindakan' => [
                'rules' => 'required|is_unique[tb_tindakan_restorasi.kode_tindakan_restorasi]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'jenistindakan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'mulai' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'selesai' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'pj' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],

        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/rencana/tindakan/' . $idrencana)->withInput()->with('validation', $validation);
        }
        $this->GambTindakanModel->save([
            'kode_rencana' => $this->request->getVar('koderencana'),
            'kode_tindakan_restorasi' => $this->request->getVar('kodetindakan'),
            'jenis_tindakan_restorasi' => $this->request->getVar('jenistindakan'),
            'tgl_mulai' => $this->request->getVar('mulai'),
            'tgl_selesai' => $this->request->getVar('selesai'),
            'pj' => $this->request->getVar('pj'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/rencana/tindakan/' . $idrencana);
    }
    public function edit_tindakan($idrencana, $id)
    {
        $this->GambTindakanModel->save([
            'id' => $id,
            'kode_rencana' => $this->request->getVar('koderencana'),
            'kode_tindakan_restorasi' => $this->request->getVar('kodetindakan'),
            'jenis_tindakan_restorasi' => $this->request->getVar('jenistindakan'),
            'tgl_mulai' => $this->request->getVar('mulai'),
            'tgl_selesai' => $this->request->getVar('selesai'),
            'pj' => $this->request->getVar('pj'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/rencana/tindakan/' . $idrencana);
    }

    public function hapus_tindakan($idrencana, $id)
    {
        $this->GambTindakanModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/rencana/tindakan/' . $idrencana);
    }
}
