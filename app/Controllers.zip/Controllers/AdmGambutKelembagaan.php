<?php

namespace App\Controllers;

use \App\Models\GambLemdesModel;
use \App\Models\GambPelaksanaModel;
use \App\Models\GambDesaModel;
use \App\Models\GambProvModel;

class AdmGambutKelembagaan extends BaseController
{
    protected $admgambutkelembagaan;
    public function __construct()
    {
        $this->GambLemdesModel = new GambLemdesModel();
        $this->GambPelaksanaModel = new GambPelaksanaModel();
        $this->GambDesaModel = new GambDesaModel();
        $this->GambProvModel = new GambProvModel();
    }
    public function index()
    {
        $lemdes = $this->GambLemdesModel->findAll();
        $pelaksana = $this->GambPelaksanaModel->findAll();
        $desa = $this->GambDesaModel->findAll();
        $prov = $this->GambProvModel->findAll();
        $data = [
            'lemdes' => $lemdes,
            'pelaksana' => $pelaksana,
            'desa' => $desa,
            'prov' => $prov,
            'title' => 'SIGAMMA | Data Kelembagaan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-kelembagaan', $data);
    }

    public function simpan_lemdes()
    {
        if (!$this->validate([
            'kodelemdes' => [
                'rules' => 'required|is_unique[tb_lemdes.kode_lemdes]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'namalemdes' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'kodedesa' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'jumlahlemdes' => [
                'rules' => 'numeric',
                'errors' => [
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/kelembagaan')->withInput()->with('validation', $validation);
        }
        $this->GambLemdesModel->save([
            'kode_desa' => $this->request->getVar('kodedesa'),
            'kode_lemdes' => $this->request->getVar('kodelemdes'),
            'nama_lemdes' => $this->request->getVar('namalemdes'),
            'jenis_lemdes' => $this->request->getVar('jenislemdes'),
            'jumlah_anggota' => $this->request->getVar('jumlahlemdes'),
            'pj' => $this->request->getVar('pjlemdes'),
            'tlpn' => $this->request->getVar('tlpnlemdes'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/kelembagaan');
    }
    public function edit_lemdes($id)
    {
        $this->GambLemdesModel->save([
            'id' => $id,
            'kode_desa' => $this->request->getVar('kodedesa'),
            'kode_lemdes' => $this->request->getVar('kodelemdes'),
            'nama_lemdes' => $this->request->getVar('namalemdes'),
            'jenis_lemdes' => $this->request->getVar('jenislemdes'),
            'jumlah_anggota' => $this->request->getVar('jumlahlemdes'),
            'pj' => $this->request->getVar('pjlemdes'),
            'tlpn' => $this->request->getVar('tlpnlemdes'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/kelembagaan');
    }

    public function hapus_lemdes($id)
    {
        $this->GambLemdesModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/kelembagaan');
    }

    public function simpan_pelaksana()
    {
        if (!$this->validate([
            'kodepelaksana' => [
                'rules' => 'required|is_unique[tb_pelaksana.kode_pelaksana]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'namapelaksana' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'jenispelaksana' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'kodeprov' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/kelembagaan')->withInput()->with('validation', $validation);
        }
        $this->GambPelaksanaModel->save([
            'kode_pelaksana' => $this->request->getVar('kodepelaksana'),
            'jenis' => $this->request->getVar('jenispelaksana'),
            'nama' => $this->request->getVar('namapelaksana'),
            'pj' => $this->request->getVar('pjpelaksana'),
            'tlpn' => $this->request->getVar('tlpnpelaksana'),
            'alamat' => $this->request->getVar('alamatpelaksana'),
            'kode_prov' => $this->request->getVar('kodeprov'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/kelembagaan');
    }
    public function edit_pelaksana($id)
    {
        $this->GambPelaksanaModel->save([
            'id' => $id,
            'kode_pelaksana' => $this->request->getVar('kodepelaksana'),
            'jenis' => $this->request->getVar('jenispelaksana'),
            'nama' => $this->request->getVar('namapelaksana'),
            'pj' => $this->request->getVar('pjpelaksana'),
            'tlpn' => $this->request->getVar('tlpnpelaksana'),
            'alamat' => $this->request->getVar('alamatpelaksana'),
            'kode_prov' => $this->request->getVar('kodeprov'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/kelembagaan');
    }

    public function hapus_pelaksana($id)
    {
        $this->GambPelaksanaModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/kelembagaan');
    }
}
