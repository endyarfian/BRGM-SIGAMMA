<?php

namespace App\Controllers;

use \App\Models\GambAlokasiModel;
use \App\Models\GambSubTindakanModel;
use \App\Models\GambPelaksanaModel;
use \App\Models\GambDesaModel;
use \App\Models\GambHruModel;
use \App\Models\GambLemdesModel;

class AdmGambutAlokasi extends BaseController
{
    protected $admgambutalokasi;
    public function __construct()
    {
        $this->GambAlokasiModel = new GambAlokasiModel();
        $this->GambSubTindakanModel = new GambSubTindakanModel();
        $this->GambPelaksanaModel = new GambPelaksanaModel();
        $this->GambDesaModel = new GambDesaModel();
        $this->GambHruModel = new GambHruModel();
        $this->GambLemdesModel = new GambLemdesModel();
    }
    public function index($idsubtindakan)
    {
        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id as idtindakan, tb_tindakan_restorasi.kode_tindakan_restorasi as kodetindakan,
        tb_sub_tindakan_restorasi.id as idsubtindakan, tb_sub_tindakan_restorasi.kode_sub_tindakan_restorasi as kodesubtindakan, tb_sub_tindakan_restorasi.nama_sub_tindakan_restorasi as namasubtindakan, 
        tb_alokasi.id, tb_alokasi.kode_alokasi, tb_alokasi.jenis_alokasi, tb_alokasi.kode_sub_tindakan_restorasi, tb_alokasi.kode_pelaksana, tb_alokasi.kode_desa, tb_alokasi.kode_hru, 
        tb_alokasi.kode_lemdes, tb_alokasi.produk, tb_alokasi.volume, tb_alokasi.satuan, tb_alokasi.pj, tb_alokasi.deskripsi
        ');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->join('tb_sub_tindakan_restorasi', 'tb_sub_tindakan_restorasi.kode_tindakan_restorasi = tb_tindakan_restorasi.kode_tindakan_restorasi');
        $data->join('tb_alokasi', 'tb_alokasi.kode_sub_tindakan_restorasi = tb_sub_tindakan_restorasi.kode_sub_tindakan_restorasi');
        $data->where('tb_sub_tindakan_restorasi.id', $idsubtindakan);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, 
        tb_tindakan_restorasi.id as idtindakan, tb_tindakan_restorasi.kode_tindakan_restorasi as kodetindakan,
        tb_sub_tindakan_restorasi.id as idsubtindakan, tb_sub_tindakan_restorasi.kode_sub_tindakan_restorasi as kodesubtindakan, tb_sub_tindakan_restorasi.nama_sub_tindakan_restorasi as namasubtindakan,
        ');
        $data->join('tb_tindakan_restorasi', 'tb_tindakan_restorasi.kode_rencana = tb_rencana.kode_rencana');
        $data->join('tb_sub_tindakan_restorasi', 'tb_sub_tindakan_restorasi.kode_tindakan_restorasi=tb_tindakan_restorasi.kode_tindakan_restorasi');
        $data->where('tb_sub_tindakan_restorasi.id', $idsubtindakan);
        $query2 = $data->get();


        $alokasi = $query->getResultArray();
        $subtindakan2 = $query2->getResultArray();
        // dd($alokasi);

        $subtindakan = $this->GambSubTindakanModel->findAll();
        $pelaksana = $this->GambPelaksanaModel->findAll();
        $desa = $this->GambDesaModel->findAll();
        $hru = $this->GambHruModel->findAll();
        $lemdes = $this->GambLemdesModel->findAll();
        $data = [
            'alokasi' => $alokasi,
            'subtindakan2' => $subtindakan2,
            'subtindakan' => $subtindakan,
            'pelaksana' => $pelaksana,
            'desa' => $desa,
            'hru' => $hru,
            'lemdes' => $lemdes,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-rencana', $data);
    }

    public function simpan_alokasi($idsubtindakan)
    {
        if (!$this->validate([
            'kodealokasi' => [
                'rules' => 'required|is_unique[tb_alokasi.kode_alokasi]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'jenis' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'subtindakan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'pelaksana' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'desa' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'hru' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'volume' => [
                'rules' => 'numeric',
                'errors' => [
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
            'satuan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'pj' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/rencana/alokasi/' . $idsubtindakan)->withInput()->with('validation', $validation);
        }
        $this->GambAlokasiModel->save([
            'kode_alokasi' => $this->request->getVar('kodealokasi'),
            'jenis_alokasi' => $this->request->getVar('jenis'),
            'kode_sub_tindakan_restorasi' => $this->request->getVar('subtindakan'),
            'kode_pelaksana' => $this->request->getVar('pelaksana'),
            'kode_desa' => $this->request->getVar('desa'),
            'kode_hru' => $this->request->getVar('hru'),
            'kode_lemdes' => $this->request->getVar('lemdes'),
            'produk' => $this->request->getVar('produk'),
            'volume' => $this->request->getVar('volume'),
            'satuan' => $this->request->getVar('satuan'),
            'pj' => $this->request->getVar('pj'),
            'deskripsi' => $this->request->getVar('deskripsi'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/rencana/alokasi/' . $idsubtindakan);
    }
    public function edit_alokasi($idsubtindakan, $id)
    {
        $this->GambAlokasiModel->save([
            'id' => $id,
            'kode_alokasi' => $this->request->getVar('kodealokasi1'),
            'jenis_alokasi' => $this->request->getVar('jenis1'),
            'kode_sub_tindakan_restorasi' => $this->request->getVar('subtindakan1'),
            'kode_pelaksana' => $this->request->getVar('pelaksana1'),
            'kode_desa' => $this->request->getVar('desa1'),
            'kode_hru' => $this->request->getVar('hru1'),
            'kode_lemdes' => $this->request->getVar('lemdes1'),
            'produk' => $this->request->getVar('produk1'),
            'volume' => $this->request->getVar('volume1'),
            'satuan' => $this->request->getVar('satuan1'),
            'pj' => $this->request->getVar('pj1'),
            'deskripsi' => $this->request->getVar('deskripsi1'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/rencana/alokasi/' . $idsubtindakan);
    }

    public function hapus_alokasi($idsubtindakan, $id)
    {
        $this->GambAlokasiModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/rencana/alokasi/' . $idsubtindakan);
    }
}
