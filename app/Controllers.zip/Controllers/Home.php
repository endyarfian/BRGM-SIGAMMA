<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('home');
    }


    public function gambutdashboard(): string
    {
        $db = \Config\Database::connect();
        $data = $db->table('tb_prov');
        $data->select('
            tb_prov.kode_prov as kodeprov, tb_prov.nama_prov, 
            COUNT(DISTINCT tb_khg.id) as total_khg,
            COUNT(DISTINCT tb_sub_khg.id) as total_sub_khg,
            COUNT(DISTINCT tb_hru.id) as total_hru
        ');
        $data->join('tb_khg', 'tb_khg.kode_prov = tb_prov.kode_prov', 'left');
        $data->join('tb_sub_khg', 'tb_sub_khg.kode_khg = tb_khg.kode_khg', 'left');
        $data->join('tb_hru', 'tb_hru.kode_sub_khg = tb_sub_khg.kode_sub_khg', 'left');
        $data->groupBy('tb_prov.kode_prov, tb_prov.nama_prov');
        $query = $data->get();

        $kawasan = $query->getResultArray();

        $kodeprov = array_column($kawasan, 'nama_prov');
        $khg = array_column($kawasan, 'total_khg');
        $subkhg = array_column($kawasan, 'total_sub_khg');
        $hru = array_column($kawasan, 'total_hru');
        // dd($kodeprov);
        $db = \Config\Database::connect();
        $data = $db->table('tb_hru');
        $data->select('SUM(luas) as total_luas');
        $query = $data->get();

        // Mengambil hasil dari query
        $result = $query->getRowArray();

        // Jumlah total luas
        $totalluas = $result['total_luas'];

        $db = \Config\Database::connect();
        $data = $db->table('tb_prov');
        $data->select('
            tb_prov.kode_prov as kodeprov, tb_prov.nama_prov, 
            SUM(tb_khg.luas) as total_khg_luas
        ');
        $data->join('tb_khg', 'tb_khg.kode_prov = tb_prov.kode_prov', 'left');
        $data->groupBy('tb_prov.kode_prov, tb_prov.nama_prov');
        $query = $data->get();

        $kawasan1 = $query->getResultArray();

        $data_luasan = [
            'data' => []
        ];
        foreach ($kawasan1 as $row) {
            $data_luasan['data'][] = [
                'x' => $row['kodeprov'],
                'y' => floatval($row['total_khg_luas'])
            ];
        }
        // dd($data_luasan);

        $data = [
            'data_luasan' => $data_luasan,
            'kodeprov' => $kodeprov,
            'khg' => $khg,
            'subkhg' => $subkhg,
            'hru' => $hru,
            'totalluas' => $totalluas,
            'title' => 'SIGAMMA | Dashboard Gambut'
        ];
        return view('pages/gamb-dashboard', $data);
    }
    public function mangrovedashboard(): string
    {
        $data = [
            'title' => 'SIGAMMA | Dashboard Mangrove'
        ];
        return view('pages/mang-dashboard', $data);
    }
}
