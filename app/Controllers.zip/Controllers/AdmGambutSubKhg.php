<?php

namespace App\Controllers;

use \App\Models\GambSubKhgModel;
use \App\Models\GambHruModel;

class AdmGambutSubKhg extends BaseController
{
    protected $admgambutkawasan;
    public function __construct()
    {
        $this->GambSubKhgModel = new GambSubKhgModel();
        $this->GambHruModel = new GambHruModel();
    }
    public function index($idsubkhg)
    {
        $db = \Config\Database::connect();
        $data = $db->table('tb_khg');
        $data->select('tb_khg.kode_khg as kodekhg, tb_khg.id as idkhg,tb_khg.nama as namakhg, tb_sub_khg.id as idsubkhg, tb_sub_khg.kode_sub_khg, tb_sub_khg.nama_sub_khg,
        tb_hru.id, tb_hru.kode_hru, tb_hru.nama_hru, tb_hru.luas, tb_hru.satuan');
        $data->join('tb_sub_khg', 'tb_sub_khg.kode_khg = tb_khg.kode_khg');
        $data->join('tb_hru', 'tb_hru.kode_sub_khg = tb_sub_khg.kode_sub_khg');
        $data->where('tb_sub_khg.id', $idsubkhg);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_khg');
        $data->select('tb_khg.kode_khg as kodekhg, tb_khg.id as idkhg,tb_khg.nama as namakhg, tb_sub_khg.id as idsubkhg, tb_sub_khg.kode_sub_khg as kodesubkhg, tb_sub_khg.nama_sub_khg as namasubkhg');
        $data->join('tb_sub_khg', 'tb_sub_khg.kode_khg = tb_khg.kode_khg');
        $data->where('tb_sub_khg.id', $idsubkhg);
        $query2 = $data->get();


        $hru = $query->getResultArray();
        $subkhg2 = $query2->getResultArray();
        // dd($hru);

        $subkhg = $this->GambSubKhgModel->findAll();
        $data = [
            'subkhg' => $subkhg,
            'subkhg2' => $subkhg2,
            'hru' => $hru,
            'title' => 'SIGAMMA | Data Kawasan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-detailsubkhg', $data);
    }

    public function simpan_hru($idsubkhg)
    {
        if (!$this->validate([
            'kodehru' => [
                'rules' => 'required|is_unique[tb_hru.kode_hru]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'namahru' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'satuanhru' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'luashru' => [
                'rules' => 'numeric',
                'errors' => [
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/kawasan/subkhg/' . $idsubkhg)->withInput()->with('validation', $validation);
        }
        $this->GambHruModel->save([
            'kode_sub_khg' => $this->request->getVar('kodesubkhg'),
            'kode_hru' => $this->request->getVar('kodehru'),
            'nama_hru' => $this->request->getVar('namahru'),
            'satuan' => $this->request->getVar('satuanhru'),
            'luas' => $this->request->getVar('luashru'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/kawasan/subkhg/' . $idsubkhg);
    }
    public function edit_hru($idsubkhg, $id)
    {
        $this->GambHruModel->save([
            'id' => $id,
            'kode_sub_khg' => $this->request->getVar('kodesubkhg'),
            'kode_hru' => $this->request->getVar('kodehru'),
            'nama_hru' => $this->request->getVar('namahru'),
            'satuan' => $this->request->getVar('satuanhru'),
            'luas' => $this->request->getVar('luashru'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/kawasan/subkhg/' . $idsubkhg);
    }

    public function hapus_hru($idsubkhg, $id)
    {
        $this->GambHruModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/kawasan/subkhg/' . $idsubkhg);
    }
}
