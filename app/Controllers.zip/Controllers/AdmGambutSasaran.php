<?php

namespace App\Controllers;

use \App\Models\GambRencanaModel;
use \App\Models\GambTargetModel;

class AdmGambutSasaran extends BaseController
{
    protected $admgambutsasaran;
    public function __construct()
    {
        $this->GambTargetModel = new GambTargetModel();
        $this->GambRencanaModel = new GambRencanaModel();
    }
    public function index($idrencana)
    {

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul, tb_target.id, tb_target.kode_target, tb_target.volume, tb_target.satuan, tb_target.deskripsi');
        $data->join('tb_target', 'tb_target.kode_rencana = tb_rencana.kode_rencana');
        $data->where('tb_rencana.id', $idrencana);
        $query = $data->get();

        $db = \Config\Database::connect();
        $data = $db->table('tb_rencana');
        $data->select('tb_rencana.kode_rencana as koderencana, tb_rencana.id as idrencana,tb_rencana.judul');
        $data->where('tb_rencana.id', $idrencana);
        $query2 = $data->get();


        $sasaran = $query->getResultArray();
        $doc2 = $query2->getResultArray();
        // dd($sasaran);

        $doc = $this->GambRencanaModel->findAll();
        $data = [
            'doc' => $doc,
            'doc2' => $doc2,
            'sasaran' => $sasaran,
            'title' => 'SIGAMMA | Data Rencana Kegiatan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-sasaran', $data);
    }

    public function simpan_sasaran($idrencana)
    {
        if (!$this->validate([
            'kodetarget' => [
                'rules' => 'required|is_unique[tb_rencana.kode_rencana]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'volume' => [
                'rules' => 'required|numeric',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
            'satuan' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/rencana/sasaran/' . $idrencana)->withInput()->with('validation', $validation);
        }
        $this->GambTargetModel->save([
            'kode_rencana' => $this->request->getVar('koderencana'),
            'kode_target' => $this->request->getVar('kodetarget'),
            'volume' => $this->request->getVar('volume'),
            'satuan' => $this->request->getVar('satuan'),
            'deskripsi' => $this->request->getVar('deskripsi'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/rencana/sasaran/' . $idrencana);
    }
    public function edit_sasaran($id, $idrencana)
    {
        $this->GambTargetModel->save([
            'id' => $id,
            'kode_rencana' => $this->request->getVar('koderencana'),
            'kode_target' => $this->request->getVar('kodetarget'),
            'volume' => $this->request->getVar('volume'),
            'satuan' => $this->request->getVar('satuan'),
            'deskripsi' => $this->request->getVar('deskripsi'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/rencana/sasaran/' . $idrencana);
    }

    public function hapus_sasaran($id, $idrencana)
    {
        $this->GambTargetModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/rencana/sasaran/' . $idrencana);
    }
}
