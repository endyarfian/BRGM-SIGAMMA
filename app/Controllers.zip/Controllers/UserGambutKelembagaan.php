<?php

namespace App\Controllers;

use \App\Models\GambLemdesModel;
use \App\Models\GambPelaksanaModel;
use \App\Models\GambDesaModel;
use \App\Models\GambProvModel;

class UserGambutKelembagaan extends BaseController
{
    protected $admgambutkelembagaan;
    public function __construct()
    {
        $this->GambLemdesModel = new GambLemdesModel();
        $this->GambPelaksanaModel = new GambPelaksanaModel();
        $this->GambDesaModel = new GambDesaModel();
        $this->GambProvModel = new GambProvModel();
    }
    public function index()
    {
        $lemdes = $this->GambLemdesModel->findAll();
        $pelaksana = $this->GambPelaksanaModel->findAll();
        $desa = $this->GambDesaModel->findAll();
        $prov = $this->GambProvModel->findAll();
        $data = [
            'lemdes' => $lemdes,
            'pelaksana' => $pelaksana,
            'desa' => $desa,
            'prov' => $prov,
            'title' => 'SIGAMMA | Data Kelembagaan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/user/gamb-kelembagaan', $data);
    }
}
