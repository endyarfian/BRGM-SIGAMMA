<?php

namespace App\Controllers;

use \App\Models\GambKhgModel;
use \App\Models\GambSubKhgModel;
use \App\Models\GambHruModel;
use \App\Models\GambProvModel;

class AdmGambutKawasan extends BaseController
{
    protected $admgambutkawasan;
    public function __construct()
    {
        $this->GambKhgModel = new GambKhgModel();
        $this->GambSubKhgModel = new GambSubKhgModel();
        $this->GambHruModel = new GambHruModel();
        $this->GambProvModel = new GambProvModel();
    }
    public function index()
    {
        $khg = $this->GambKhgModel->findAll();
        $subkhg = $this->GambSubKhgModel->findAll();
        $hru = $this->GambHruModel->findAll();
        $prov = $this->GambProvModel->findAll();
        $data = [
            'prov' => $prov,
            'khg' => $khg,
            'subkhg' => $subkhg,
            'hru' => $hru,
            'title' => 'SIGAMMA | Data Kawasan Gambut',
            'validation' => \Config\Services::validation(),
        ];
        return view('database/admin/gamb-kawasan', $data);
    }

    public function simpan_khg()
    {
        if (!$this->validate([
            'kodekhg' => [
                'rules' => 'required|is_unique[tb_khg.kode_khg]',
                'errors' => [
                    'required' => 'Data harus diisi.',
                    'is_unique' => 'Data sudah tercatat dalam database.'
                ]
            ],
            'namakhg' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Data harus diisi.',
                ]
            ],
            'lindungkhg' => [
                'rules' => 'numeric',
                'errors' => [
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
            'budidayakhg' => [
                'rules' => 'numeric',
                'errors' => [
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
            'luaskhg' => [
                'rules' => 'numeric',
                'errors' => [
                    'numeric' => 'Data harus berupa angka.',
                ]
            ],
        ])) {
            $validation = $this->validator->getErrors();
            return redirect()->to('admin/gambut/kawasan')->withInput()->with('validation', $validation);
        }
        $this->GambKhgModel->save([
            'kode_khg' => $this->request->getVar('kodekhg'),
            'nama' => $this->request->getVar('namakhg'),
            'kode_prov' => $this->request->getVar('kodeprov'),
            'fungsi_lindung' => $this->request->getVar('lindungkhg'),
            'fungsi_budidaya' => $this->request->getVar('budidayakhg'),
            'luas' => $this->request->getVar('luaskhg'),
            'satuan' => $this->request->getVar('satuankhg'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data sudah tersimpan. 👍']);
        return redirect()->to('admin/gambut/kawasan');
    }
    public function edit_khg($id)
    {
        $this->GambKhgModel->save([
            'id' => $id,
            'kode_khg' => $this->request->getVar('kodekhg'),
            'nama' => $this->request->getVar('namakhg'),
            'kode_prov' => $this->request->getVar('kodeprov'),
            'fungsi_lindung' => $this->request->getVar('lindungkhg'),
            'fungsi_budidaya' => $this->request->getVar('budidayakhg'),
            'luas' => $this->request->getVar('luaskhg'),
            'satuan' => $this->request->getVar('satuankhg'),
        ]);
        session()->setFlashdata(['info' => 'success', 'judul' => 'MANTAP KAWAN!👍', 'pesan' => 'Data telah diperbarui. 👍']);
        return redirect()->to('admin/gambut/kawasan');
    }

    public function hapus_khg($id)
    {
        $this->GambKhgModel->delete($id);
        session()->setFlashdata(['info' => 'error', 'judul' => 'SAYANG SEKALI 😞', 'pesan' => 'Data sudah terhapus. 😞']);
        return redirect()->to('admin/gambut/kawasan');
    }
}
